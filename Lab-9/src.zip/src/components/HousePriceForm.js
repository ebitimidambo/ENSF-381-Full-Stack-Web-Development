import { useEffect, useState, createContext } from "react"

function HousePriceForm(){
    const [city, setCity] = useState('')
    const [province, setProvince] = useState('')
    const [latitude, setLatitude] = useState('')
    const [longitude, setLongitude] = useState('')
    const [lease, setLease] = useState('')
    const [type, setType] = useState('')
    const [beds, setBeds] = useState('')
    const [baths, setBaths] = useState('')
    const [square, setSquare] = useState('')
    const [smoking, setSmoking] = useState('')
    const [pet, setPet] = useState(false)
    const [furnishing, setFurnishing] = useState('')
    const [predictedPrice, setPredictedPrice] = useState(null)
    const [priceObtained, setPriceObtained] = useState(false)
    const [error, setError] = useState(false)

    const cityChange = (event) => {
        setCity(event.target.value)
    }

    const provinceChange = (event) => {
        setProvince(event.target.value)
    }

    const latitudeChange = (event) => {
        setLatitude(event.target.value)
    }

    const longitudeChange = (event) => {
        setLongitude(event.target.value)
    }

    const leaseChange = (event) => {
        setLease(event.target.value)
    }

    const typeChange = (event) => {
        setType(event.target.value)
    }

    const bedsChange = (event) => {
        setBeds(event.target.value)
    }

    const bathsChange = (event) => {
        setBaths(event.target.value)
    }

    const squareChange = (event) => {
        setSquare(event.target.value)
    }

    const smokingChange = (event) => {
        setSmoking(event.target.value)
    }

    const petChange = (event) => {
        setPet(event.target.checked)
    }

    const furnishingChange = (event) => {
        setFurnishing(event.target.value)
    }

    const handleSubmit = async(event) => {
        event.preventDefault();

        const data = {
            city,
            province,
            latitude,
            longitude,
            lease_term: lease,
            type,
            beds,
            baths,
            sq_feet: square,
            furnishing,
            smoking,
            pets: pet
        }

        const backendEndpoint = 'http://127.0.0.1:5000/predict_house_price';
    
        try {
            const response = await fetch(backendEndpoint, {
                method: 'POST',
                headers: {
                'Content-Type': 'application/json',
            },
                body: JSON.stringify(data),
            });
            
            
            if (response.ok) {
                const result = await response.json();
                console.log(result.predicted_price)
                setPredictedPrice(result.predicted_price)
                setPriceObtained(true)

                setTimeout(() => {
                    setPriceObtained(false)
                }, 10000);
                console.log("Yipee")
            } else {
                setError(true)

                setTimeout(() => {
                    setError(false)
                }, 10000);
            }
            } catch (error) {
                console.error('Error during form submission:', error);  };
    }
    return(
        <main id="predictmain">

            <form id="price-form" onSubmit={(e) => handleSubmit(e)}>
                <h2>House Price Form</h2>
                <label for="username">City:</label>
                <input type="text" id="city" name="city" onChange={cityChange} required></input><br></br>
                <label for="province">Province:</label> 
                <input type="text" id="province" name="province" onChange={provinceChange} required></input><br></br>
                <label for="latitude">Latitude:</label> 
                <input type="text" id="latitude" name="latitude" onChange={latitudeChange}  required></input><br></br>
                <label for="longitude">Longitude:</label> 
                <input type="text" id="longitude" name="longitude" onChange={longitudeChange}  required></input><br></br>
                <label for="lease">Lease Term:</label> 
                <input type="text" id="lease" name="lease" onChange={leaseChange}  required></input><br></br>
                <label for="type">Type:</label> 
                <input type="text" id="type" name="type" onChange={typeChange}  required></input><br></br>
                <label for="beds">Beds:</label> 
                <input type="text" id="beds" name="beds" onChange={bedsChange} required></input><br></br>
                <label for="baths">Baths:</label> 
                <input type="text" id="baths" name="baths" onChange={bathsChange}  required></input><br></br>
                <label for="square">Square Feet:</label> 
                <input type="text" id="square" name="square" onChange={squareChange}  required></input><br></br>
                <label  for="furnishing">Furnishing:</label> 
                <select id="furnishing" name="furnishing" onChange={furnishingChange} required>
                    <option value="unfurnished">Unfurnished</option>
                    <option value="semi-furnished">Semi-Furnished</option>
                    <option value="furnished">Furnished</option>
                </select>
                <label for="smoking" id="special">Smoking:</label> 
                <select id="smoking" name="smoking" onChange={smokingChange} required>
                    <option value="yes">Yes</option>
                    <option value="semi-no">No</option>
                </select>

                <label for="1">I have a pet:</label>
                <input type="checkbox" id="1" name="pet" onChange={petChange}/>

                <div id="login">
                    <button id = "loginbutton">Predict</button>
                </div>
            </form>
            {priceObtained &&
                <div className = "Price">
                    <p>Predicted Rent Price: {predictedPrice}</p>
                </div>
            }
            {error &&
                <div className = "Error">
                    <p>Error with data. Try again</p>
                </div>
            }
        </main>
    )
}

export default HousePriceForm