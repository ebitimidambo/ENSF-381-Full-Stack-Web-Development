function Footer(){
    return(
        <footer>
            <p>&copy; 2025 HMS. All rights reserved.</p>
        </footer>
    )
}

export default Footer;