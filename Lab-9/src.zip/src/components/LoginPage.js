import { useEffect, useState, createContext } from "react"
import AuthMessage from "./AuthMessage"
export const validate_login = createContext(null)


function LoginForm(){
    const [loginClicked, setLoginClicked] = useState(false)
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [userFound, setUserFound] = useState(false)
    
    const userChange = (event) => {
        setUsername(event.target.value)
    }
    
    const passwordChange = (event) => {
        setPassword(event.target.value)
    }

    const validateLogin = async (event, username, password) => {
        event.preventDefault();
        var validUsername = username.length > 0
        var validPassword = password.length >= 8
    
        if (validUsername && validPassword){
    
            const backendEndpoint = 'http://127.0.0.1:5000/validate_login';
    
            try {
                const response = await fetch(backendEndpoint, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({'username':username , 'password':password}),
                });
            
                const data = await response.text();
                console.log(data)
            
                if (response.ok) {
                    setUserFound(true)
                    setLoginClicked(true)
                } else {
                    setUserFound(false)
                    setLoginClicked(true)
                }
              } catch (error) {
                console.error('Error during form submission:', error);  };
                
        } else {
            if (!validUsername) alert("Username must not be null")
            if (!validPassword) alert("Password must be at least eight characters")
        }
    }
    

    return(
        <main id="loginmain">
            <form id="login-form" onSubmit={(e) => validateLogin(e, username, password)}>
                <h2>Login Form</h2>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username"  onChange={userChange} required></input><br></br>
                <label for="password">Password:</label> 
                <input type="password" id="password" name="password" onChange={passwordChange} required></input><br></br>
                <div id="login">
                    <button id = "loginbutton">Login</button>
                </div>
            </form>
            {loginClicked && (
                <validate_login.Provider value={{username, password}}>
                    <AuthMessage onHandled = {() => setLoginClicked(false)} found={userFound}/>
                </validate_login.Provider>
            )}
        </main>
    )
}

export default LoginForm