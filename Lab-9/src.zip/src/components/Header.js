import logo from '../images/logo.png'
import { Link } from 'react-router-dom';

function Headers(){
    return(
        <div>
            <header>
                <img src={logo} alt=""></img>
                <h1>HMS - Home Management System</h1>
            </header>
            <div>
                <nav>
                    <Link to={"/"}>Login</Link> |
                    <Link to={"/home"}>Home</Link>
                </nav>
            </div>
        </div>
    );
};

export default Headers;