import { useEffect, useState, useContext, useRef } from "react"
import { validate_login } from "./LoginPage";
import DisplayStatus from "./DisplayStatus";
import { useNavigate } from 'react-router-dom';


function AuthMessage({onHandled, found}){
    const {username, password} = useContext(validate_login)
    const [state, setStatus] = useState(null)
    const hasRun = useRef(false)
    const navigate = useNavigate()

    useEffect(() => {
        if(hasRun.current) return;
        hasRun.current = true
        
        if (found) {
            console.log("Success")
            setStatus("Success")
            setTimeout(() => {
                navigate("/predict")
                if (onHandled) onHandled()
            }, 2000);
            } else {
                setStatus("Fail")
                console.log("Fail")
                setTimeout(() => {
                if (onHandled) onHandled()
            }, 3000);
        };
        console.log("called")

        }, [username, password]
    )

    console.log("AuthMessage state:", state);
    if (state === "Success"){
        return(
            <DisplayStatus type={"Success"} message={"Login Successful! Redirecting..."}/>
        )
    } else if (state === "Fail"){
        return(
            <DisplayStatus type={"Error"} message={"Invalid username or password"}/>
        )
    }

}

export default AuthMessage