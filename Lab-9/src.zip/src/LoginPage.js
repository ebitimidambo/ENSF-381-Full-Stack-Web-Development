import logo from './logo.svg';
import './App.css';
import Header from './components/Header.js';
import LoginForm from './components/LoginPage.js';
import Footer from './components/Footer.js';

function LoginPage() {
    return (
        <div>
            <Header />
            <LoginForm/>
            <Footer />
        </div>
    )
}

export default LoginPage