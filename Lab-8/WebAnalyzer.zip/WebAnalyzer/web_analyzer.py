import requests
from bs4 import BeautifulSoup
from collections import Counter
import string
import matplotlib.pyplot as plt
url = "https://en.wikipedia.org/wiki/University_of_Calgary"

try:
    response = requests.get(url)
    response.raise_for_status() # Ensures the request was successful
    soup = BeautifulSoup(response.text, 'html.parser')
    print(f"Successfully fetched content from {url}")
except Exception as e:
    print(f"Error fetching content: {e}")

#print(soup.prettify())

#--------------------------------------------------------------------------------------------------------------------
headings = ["h1", "h2", "h3", "h4", "h5", "h6"]
count = []
total_headings = 0

for heading in headings:
    list = soup.find_all(heading)
    count.append (len(list))

for numbers in count:
    total_headings += int(numbers)

print(f"Number of <h1> to <h6> elements: {total_headings}")
#--------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------
total_links = len(soup.find_all("a"))
print(f"Number of <a> elements: {total_links}")
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------
total_par = len(soup.find_all("p"))
print(f"Number of <p> elements: {total_par}")
#--------------------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------------
user_input = input("What phrase would you like to look for: ")
text = soup.get_text().lower()
test = text.count(user_input.lower())
print(f"Number of occurences of {user_input}: {test}")
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------

text = soup.get_text()
refined_text = text.split()
lowered_text = []

for element in refined_text:
    translator = str.maketrans('', '', string.punctuation)
    element = element.translate(translator)
    lowered_text.append(element.lower())

counts = Counter(lowered_text)

top_words = counts.most_common(5)

print("\nTop 5 Most Used Words:")
for word, freq in top_words:
    print(f"{word}: {freq} words")

'''
During the completion of this lab, we noticed that the frequency of words for exercises 4 and 5 do not match with
some being of higher frequency than the other. We have determined that this makes sense! Consider the word
"olympics". Exercise 4 requires us to find a phrase which means the word "olympic" will still appear in olympics. However
in exercise 5, this requires us to find the exact word and involves splitting the test. This is why olympic will not
appeear in olympics. Thank you so much!
'''
#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------

try:
    paragraphs = soup.find_all("p")
    longest_paragraph = ""
    max_word_count = 0

    for p in paragraphs:
        text = p.get_text().strip()
        words = text.split() 

        if len(words) >= 5:
            if len(words) > max_word_count:
                max_word_count = len(words)
                longest_paragraph = text

    if longest_paragraph:
        print(f"\nLongest paragraph ({max_word_count} words):\n")
        print(longest_paragraph)
    else:
        print("No suitable paragraph found.")
except Exception as e:
    print(f"Error fetching content: {e}")

#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------
labels = ['Headings', 'Links', 'Paragraphs']
values = [total_headings, total_links, total_par]
plt.bar(labels, values)
plt.title('Put your Group# Here')
plt.ylabel('Count')
plt.show()