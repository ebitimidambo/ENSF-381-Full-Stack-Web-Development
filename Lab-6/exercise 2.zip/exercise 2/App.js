import logo from './logo.svg';
import './App.css';
import Home from './Home.js';
import About from './About.js';
import Contact from './Contact.js';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Home title = "Home Page" description = "Welcome to our website"/>
        <About title = "About Page" description = "We are passionate about delivering quality experiences"/>
        <Contact title = "Contact Page" description = "Feel free to reach out to us via email or phone"/>
      </header>
    </div>
  );
}

export default App;
