import logo from './logo.svg';
import './App.css';

var currentYear = new Date();
var isLoggedIn = false;
var name;
(isLoggedIn == true)? name = "Welcome back!": name = "Please Login.";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>ENSF-381: Full Stack Web Development</h1>
        <p>React Components</p>
        <p>{currentYear.getFullYear()}</p>
        <p>{name}</p>
      </header>
    </div>
  );
}

export default App;
